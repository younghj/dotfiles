print "yes"
a = 5
if a == 5:
    print "no"
else:
    print "yes"
