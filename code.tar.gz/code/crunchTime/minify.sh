#!/bin/bash
rm -rf js/*-min.js
rm -rf js/user/*-min.js
rm -rf js/employee/*-min.js
rm -rf landing/landing/*-min.js
rm -rf css/*-min.css
cd js/
java -jar ../libs/yuicompressor-2.4.8.jar -o '.js$:-min.js' *.js
cd user/
java -jar ../../libs/yuicompressor-2.4.8.jar -o '.js$:-min.js' *.js
cd ../employee/
java -jar ../../libs/yuicompressor-2.4.8.jar -o '.js$:-min.js' *.js
cd ../landing/
java -jar ../../libs/yuicompressor-2.4.8.jar -o '.js$:-min.js' *.js
cd ../../css
java -jar ../libs/yuicompressor-2.4.8.jar -o '.css$:-min.css' *.css
