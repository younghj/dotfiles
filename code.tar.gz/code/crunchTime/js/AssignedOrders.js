/**
 * Register object for crunchtime events
 */
document.addEventListener("CrunchTime.User.Startup", function() {
  CrunchTime.AssignedOrders.init();
}, false);

document.addEventListener("CrunchTime.Employee.Startup", function() {
  CrunchTime.AssignedOrders.init();
}, false);

document.addEventListener("CrunchTime.ClearCache", function() {
  CrunchTime.AssignedOrders.reset();
}, false);

CrunchTime.AssignedOrders = {
  POLL_TIME: 10000,

  Order: Parse.Object.extend("Order"),

  userCache: {},
  emplCache: {},

  statuses: ["Pending", "In Progress", "Delivering", "Arrived", "Paid", "DONE"],
  DASHBOARD_EMPL: "empl",
  DASHBOARD_USER: "user",

  /**
   * Get orders
   * @returns {Parse.Promise<Parse.Object[]>}
   */
  getOrderInfo: function() {
    var _this = this;

    var query = new Parse.Query(this.Order);
    query.equalTo("orderedBy", Parse.User.current());
    query.notEqualTo("status", _this.statuses[_this.statuses.length-1]);
    query.include("orderItems.restaurant");
    query.include("meetingPlace");

    return query.find().then(function(orderList) {
      _this.removeFinishedOrders(orderList, _this.DASHBOARD_USER);
	  return orderList;

    }, function(error) {
      // console.error("Update order failed", error);
    });
  },

  /**
   * Remove any finished orders
   * We do this so that we can update a cache instead of re-drawing order cards on ui
   * @param {Parse.Object[]} orderList
   */
  removeFinishedOrders: function(orderList, dashboardType) {
    var orderIds = orderList.map(function(order){return order.id;});
	var orderCache = this[dashboardType+"Cache"];
	for (var orderCached in orderCache) {
	  if (!~orderIds.indexOf(orderCached)) {
		this.removeOrderFromPage(orderCached, dashboardType);
	  }
	}
  },

  /**
  * Get orders assigned to current user
  * @returns {Parse.Promise<Parse.Object[]>}
  */
  getTaskInfo: function() {
    var _this = this;
    var query = new Parse.Query(this.Order);
    query.equalTo("assignedTo", Parse.User.current());
    query.notEqualTo("status", _this.statuses[_this.statuses.length-1]);
    query.include("orderItems.restaurant");
    query.include("meetingPlace");
    query.include("orderedBy");

    return query.find().fail(function(error) {
      // console.error("Update task failed", error);
    });
  },

  /**
  * Add list of orders to dashboard
  * @param {Parse.Object[]} orderList
  */
  updateDashboard: function(orderList, dashboardType) {
	var _this = this;
    var elContainer = $("#" + dashboardType + "_order_container");

    if (dashboardType === _this.DASHBOARD_EMPL) {
      if (orderList.length === 0) {
		if (elContainer.find("#" + dashboardType + "-empty").length === 0) {
			elContainer.prepend('<div id="' + dashboardType + '-empty">No Tasks, all done for now! Check below to pick up any new orders!</div>');
		}
        return;
      }
    }
    else if (dashboardType === _this.DASHBOARD_USER) {
      if (orderList.length === 0) {
		if (elContainer.find("#" + dashboardType + "-empty").length === 0) {
			elContainer.prepend('<div id="'+ dashboardType + '-empty">No orders, make an order below!</div>');
		}
        return;
      }
    }
	elContainer.remove("#" + dashboardType + "-empty");

    orderList.forEach(function(order) {
      // if we already have the order in the cache
      if (this[dashboardType + "Cache"][order.id] != null) {
        // no status updates
        if (this[dashboardType + "Cache"][order.id].get("status") === order.get("status")) {
          return;
        }
        else {
          this[dashboardType + "Cache"][order.id] = order;
          var elOrderToUpdate = $("#" + dashboardType + "-order-" + order.id);
          this.updateStatusAndUpdateTime(elOrderToUpdate, order, dashboardType);
		  return;
        }
      }

      this[dashboardType + "Cache"][order.id] = order;

	  // find template
      var elOrder = elContainer.find("#TYPE-order-ID.template").clone();
      elOrder.removeClass("template");

	  // replace template ids
	  var _order = order;
	  // replace all order templates
	  elOrder.find("[id^='TYPE']").andSelf().not("[id^='TYPE-orderitem'], .template").each(function(){
		this.id = _this.replaceID(this.id, _order.id, dashboardType);
	  });
      elOrder.show();

      //orderUser
      if (dashboardType === _this.DASHBOARD_EMPL) {
        var orderBy = order.get("orderedBy");

        var firstName = orderBy.get("firstName");
        var lastName = orderBy.get("lastName");
        var fullName =  firstName + " " + lastName;

        var contactInfo = "";
        var hasEmail = orderBy.has("email");
        var hasPhone = orderBy.has("phone");
        if (hasEmail && hasPhone) {
          contactInfo = orderBy.get("email") + " / " + orderBy.get("phone");
        } else if (hasEmail) {
          contactInfo = orderBy.get("email");
        } else if (hasPhone) {
          contactInfo = orderBy.get("phone");
        }

        var elOrderUser = elOrder.children("#" + dashboardType + "-orderuser-" + order.id);
        var elOrderUserName = elOrderUser.children("#" + dashboardType + "-orderuser-" + order.id + "-fullName");
        elOrderUserName.text(fullName);
        var elOrderUserContact = elOrderUser.children("#" + dashboardType + "-orderuser-" + order.id + "-contactInfo");
        elOrderUserContact.text(contactInfo);

        elOrderUser.attr("onclick","CrunchTime.Home.toggleCollapse(this)");
        elOrderUser.find('.arrow .glyphicon').show();
      } else if (dashboardType === _this.DASHBOARD_USER) {
        elContainer.remove("#" + dashboardType + "-orderuser-" + order.id);
      }

      //orderItems
      order.get("orderItems").forEach(function(orderItem) {
        var elOrderItem = elOrder.find("#TYPE-orderitem-ID.template").clone();
        elOrderItem.removeClass("template");

        elOrderItem.attr("onclick","CrunchTime.Home.toggleCollapse(this)");
        elOrderItem.find('.arrow .glyphicon').show();

    		elOrderItem.find("[id^='TYPE-orderitem']").andSelf().not(".template").each(function(){
    			// replace all orderitem templates
    			this.id = _this.replaceID(this.id, orderItem.id, dashboardType);
    		});

        elOrderItem.show();
        var elRestaurant = elOrderItem.children("#" + dashboardType + "-orderitem-" + orderItem.id + "-restaurant");
        elRestaurant.text(orderItem.get("restaurant").get("name"));
        var elDesc = elOrderItem.children("#" + dashboardType + "-orderitem-" + orderItem.id + "-desc");
        elDesc.text(orderItem.get("description"));

        elOrder.find(".orderItem").last().before(elOrderItem);
      }, this);

      //meetingPlace
      var elMeetingPlace = elOrder.children("#" + dashboardType + "-meetingplace-" + order.id);

      var meetingPlaceFull = order.get("meetingPlace").get("description");
      var meetingPlaceShort = meetingPlaceFull.split(':')[0];
      var meetingPlaceDescription = meetingPlaceFull.split(':')[1];

      var elMeetingPlaceShort = elMeetingPlace.children("#" + dashboardType + "-meetingplace-" + order.id + "-shortName");
      elMeetingPlaceShort.text("Meet @ " + meetingPlaceShort);

      var elMeetingPlaceShortDesc = elMeetingPlace.children("#" + dashboardType + "-meetingplace-" + order.id + "-description");
      elMeetingPlaceShortDesc.text(meetingPlaceDescription);

      this.updateStatusAndUpdateTime(elOrder, order, dashboardType);

      // Order time
      var elOrdered = elOrder.children("#" + dashboardType + "-ordertime-" + order.id);

      var elOrderedPretty = elOrdered.children("#" + dashboardType + "-ordertime-" + order.id + "-pretty");
      elOrderedPretty.text("Ordered " + prettyDate(order.createdAt));

      var elOrderedFull = elOrdered.children("#" + dashboardType + "-ordertime-" + order.id + "-fullDate");
      elOrderedFull.text(order.createdAt.toLocaleString());

	  // insert before template
      elContainer.children("#TYPE-order-ID.template").before(elOrder);
    }, this);
  },

  updateStatusAndUpdateTime: function(elOrder, order, dashboardType) {
    // Status
    var elStatus = elOrder.find("#" + dashboardType + "-status-" + order.id);
    elStatus.text(order.get("status"));

    if (dashboardType === this.DASHBOARD_EMPL) {
	  // TODO: this needs to be better, don't unbind and rebind
      elStatus.off("click").on("click", function(){
        CrunchTime.AssignedOrders.nextStatus(order.id);
      });
    }
    else {
      elStatus.prop("disabled", true);
    }

    // Update time
    var elUpdated = elOrder.children("#" + dashboardType + "-updatetime-" + order.id);
    var elUpdatedPretty = elUpdated.children("#" + dashboardType + "-updatetime-" + order.id + "-pretty");
	elUpdatedPretty.text("Updated " + prettyDate(order.updatedAt));
    var elUpdatedFull = elUpdated.children("#" + dashboardType + "-updatetime-" + order.id + "-fullDate");
    elUpdatedFull.text(order.updatedAt.toLocaleString());
  },

  /**
   * Remove order from page and from appropriate cache
   * @param {String} id            order id
   * @param {String} dashboardType
   */
  removeOrderFromPage: function(id, dashboardType) {
	// remove from both empl and user
	if (dashboardType == null) {
		$("#" + this.DASHBOARD_EMPL + "-order-" + id).remove();
		delete this[this.DASHBOARD_EMPL + "Cache"][id];
		$("#" + this.DASHBOARD_USER + "-order-" + id).remove();
		delete this[this.DASHBOARD_USER + "Cache"][id];
	}
	else {
		$("#" + dashboardType + "-order-" + id).remove();
		delete this[dashboardType + "Cache"][id];
	}
  },

  nextStatus: function(id) {
    // TODO: update time as well, use updateStatusAndUpdateTime
    var taskStatus = $("#" + this.DASHBOARD_EMPL + "-status-" + id);
    var index = this.statuses.indexOf(taskStatus.text()) + 1;
    if (index < 0) index = 0;
    if (index >= this.statuses.length-1) {
      this.removeOrderFromPage(id, this.DASHBOARD_EMPL);
    }
    else {
      taskStatus.text(this.statuses[index]);
    }
    taskStatus.prop("disabled", true);
    Parse.Cloud.run("nextOrderStatus", {orderId: id}, {
      success: function(taskStatusFromServer) {
        if (taskStatus != null) {
          taskStatus.val(taskStatusFromServer);
          taskStatus.prop("disabled", false);
        }
      },
      error: function(error) {
          taskStatus.prop("disabled", false);
      }
    });
  },

  formatTime: function(hour, minute) {
    if(hour < 10) {
        hour = "0" + hour;
    }
    if(minute < 10) {
        minute = "0" + minute;
    }
    return hour + ":" + minute;
  },

  updateTasks: function() {
    var _this = this;

    return this.getTaskInfo().then(function(taskList) {
      _this.updateDashboard(taskList, _this.DASHBOARD_EMPL);
    });
  },

  updateOrders: function() {
    var _this = this;

    return this.getOrderInfo().then(function(orderList){
      _this.updateDashboard(orderList, _this.DASHBOARD_USER);

    });
  },

  pollOrders: function() {
    return this.updateOrders().fail(function(error) {
      //console.error(error);
    });
  },

  pollTasks: function() {
    return this.updateTasks().fail(function(error) {
      // console.error(error);
    });
  },

  reset: function() {
    for (var id in this.userCache) {
      delete this.userCache[id];
    }

    for (var id in this.emplCache) {
      delete this.emplCache[id];
    }

    $('.taskboard-row').remove();
    $('.dashboard-row').remove();
  },

  replaceID: function(orig, id, dashboardType) {
    return orig.replace("ID", id).replace("TYPE", dashboardType);
  },

  init: function() {
    //register polling tasks with home page
    CrunchTime.Home.pollingUtils.register("Employee", "Tasks", this.POLL_TIME, this.pollTasks, this);
    CrunchTime.Home.pollingUtils.register("User", "Order", this.POLL_TIME, this.pollOrders, this);
  }
};
