/**
 * Register object for crunchtime events
 */
document.addEventListener("CrunchTime.Employee.Startup", function() {
  CrunchTime.IncomingOrders.init();
}, false);

document.addEventListener("CrunchTime.ClearCache", function() {
  CrunchTime.IncomingOrders.reset();
}, false);


window.CrunchTime.IncomingOrders = {
  POLL_TIME: 30000, //30 seconds
  ORDER_UNASSIGNED_LIMIT: 120000, // 2 minutes

  //unassigned orders cache
  unassignedOrdersCache: {},

  orderObj: Parse.Object.extend("Order"),

  employeesCache: [],

  isPolling: false,

  /**
   * Contains simple methods to update page.
   * You can replace the methods in this with your own ui functions if you so desire.
   ** The function signatures MUST remain the same however.
   * @type {Object}
   */
  ui: {
    /**
     * Display new order on page
     * @param {Parse.Object} order
     */
    addOrderToPage: function(order) {
      var elOrder = $('<li></li>');

      var orderBy = order.get("orderedBy");
      var firstName = orderBy.get("firstName");
      var lastName = orderBy.get("lastName");
      var fullName =  firstName + " " + lastName;

      var contactInfo = "";
      var hasEmail = orderBy.has("email");
      var hasPhone = orderBy.has("phone");
      if (hasEmail && hasPhone) {
        contactInfo = orderBy.get("email") + " / " + orderBy.get("phone");
      } else if (hasEmail) {
        contactInfo = orderBy.get("email");
      } else if (hasPhone) {
        contactInfo = orderBy.get("phone");
      }
            
      var meetingPlaceFull = order.get("meetingPlace").get("description");
      var meetingPlace = meetingPlaceFull.split(':')[0];

      var orderMessage = "A new order is available! - " + fullName + " (" +  contactInfo + ") meeting at " + meetingPlace + " ";
      elOrder.text(orderMessage);
      elOrder.attr("id", "incoming_order_" + order.id);

      var elBtnAccept = $('<button class="btn btn-default">Take order</button>');

      elBtnAccept.on("click", function(e) {
        CrunchTime.IncomingOrders.confirmOrder(order).then(
          function(order) {
            CrunchTime.AssignedOrders.updateOrders();
          }
        );
      });

      elOrder.append(elBtnAccept);
      $("#unassigned_orders ul").prepend(elOrder);
    },

    /**
     * Remove order element
     * @param {Parse.Object} order
     */
    removeOrderFromPage: function(order) {
      $("#incoming_order_" + order.id).remove();
    },

    /**
     * Clear out any remaining ui elements on the screen related to incomming orders
     */
    reset: function() {
      $("#unassigned_orders ul").html('');
    }
  },

  /**
   * Query for new unassigned orders and cached orders (to update)
   * @returns {Parse.Promise}
   */
  queryOrders: function() {
    //query for all unassigned orders
    var unassignedOrdersQuery = new Parse.Query(this.orderObj);
    unassignedOrdersQuery.doesNotExist("assignedTo");

    //query for orders in existing cache
    var cachedOrdersQuery = new Parse.Query(this.orderObj);
    cachedOrdersQuery.containedIn("objectId", Object.keys(this.unassignedOrdersCache));

    var mainQuery = Parse.Query.or(unassignedOrdersQuery, cachedOrdersQuery);
    mainQuery.include("meetingPlace");
    mainQuery.include("orderedBy");

    return mainQuery.find();
  },

  /**
   * Update order list with updated times and determine order assignment
   * @param {Parse.Object[]} ordersList
   */
  processQueriedOrders: function(ordersList) {
    var promise = Parse.Promise.as();

    ordersList.forEach(function(order) {
      //previously unassigned order on page is now assigned
      if (order.has("assignedTo")) {
        this.ui.removeOrderFromPage(this.unassignedOrdersCache[order.id]);
        delete this.unassignedOrdersCache[order.id];

      } else {
        // *****AUTO ASSIGN*****
        /* var now = new Date();

        //auto assign if order is left unassigned for too long
        if ((now.getTime() - order.createdAt.getTime()) >= this.ORDER_UNASSIGNED_LIMIT) {
          var _this = this;
          promise = promise.then(function() {
            return _this.autoAssign(order);
          });

          //new order
        } else */ if (typeof(this.unassignedOrdersCache[order.id]) === "undefined") {
          this.unassignedOrdersCache[order.id] = order;
          this.ui.addOrderToPage(order);
        }
      }
    }, CrunchTime.IncomingOrders);

    return promise;
  },

  /**
   * Assign order to random employee
   * @param {Parse.Object} order
   * @returns {Parse.Promise <Parse.Object>}
   */
  // *****AUTO ASSIGN*****
  /*autoAssign: function(order) {
    var promise;

    if (this.employeesCache.length === 0) {
      promise = this.getEmployees();
    } else {
      promise = Parse.Promise.as();
    }

    var _this = this;
    return promise.then(function() {
      //determine random employee:
      var employeeIndex = Math.floor(Math.random() * _this.employeesCache.length);
      // console.info('auto assigning to employee', this.employeesCache[employeeIndex]);

      return _this.confirmOrder(order, _this.employeesCache[employeeIndex]);
    });
  },*/

  /**
   * For employees to confirm a order.
   * @param {Parse.Object <Order>} order Order to confirm
   * @param {Parse.User} [user=Parse.User.current()]  Can pass in specific user to assign to as assignedTo. Current user by default.
   *
   * @returns {Parse.Promise <Parse.Object>} returns confirmed order
   */
  confirmOrder: function(order, user) {
    var employee = Parse.User.current();

    if (typeof(user) !== "undefined" && (user instanceof Parse.User)) {
      employee = user;
    }

    var _this = this;
    return order.fetch().then(function(order) {
      if (!order.has("assignedTo")) {
        return order.save({
          "assignedTo": employee
        });

      } else {
        //remove order and alert user if already taken
        _this.ui.removeOrderFromPage(order);
        delete _this.unassignedOrdersCache[order.id];

        alert("Order was already taken by someone else!");
        return Parse.Promise.error("Order is already taken!");
      }

    }).then(function(order) {
      _this.ui.removeOrderFromPage(order);
    });

  },

  /**
   * Query for and cache current list of employees so we don't query multiple times for auto-assigning
   */
  getEmployees: function() {
    var _this = this;

    return CrunchTime.query.role("Employee").then(function(employeeRole) {
      return employeeRole.getUsers().query().find();

    }).then(function(employees) {
      _this.employeesCache = employees;

    });
  },

  /**
   * Poll and display unassigned orders
   * @returns {Parse.Promise}
   */
  poll: function() {
    return this.queryOrders()
      .then(this.processQueriedOrders)
      .fail(function(error) {
        // console.error(error);
      });
  },

  /**
   * Call after logout to reset cache and stop polling
   */
  reset: function() {
    //clear caches
    for (var id in this.unassignedOrderCache) {
      delete this.unassignedOrderCache[id];
    }

    while (this.employeesCache > 0) {
      this.employeesCache.pop();
    }

    this.ui.reset();
  },

  /**
   * Call after login to poll for unassigned orders
   */
  init: function() {
    //register polling tasks with home page
    CrunchTime.Home.pollingUtils.register("Employee", "IncomingOrders", this.POLL_TIME, this.poll, this);
  }
};
