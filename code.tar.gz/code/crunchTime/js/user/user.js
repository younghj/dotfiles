/**
 * Register object for crunchtime events
 */
document.addEventListener("CrunchTime.User.Startup", function() {
  CrunchTime.User.init();
}, false);

CrunchTime.User = {
  init: function() {
    $(document).ready(function(){
      var orderTemplate = CrunchTime.orderTemplate.cloneNode(true);
      orderTemplate.id = CrunchTime.orderTemplate.id.replace("TYPE", CrunchTime.AssignedOrders.DASHBOARD_USER);
      $("#order-dashboard").append(orderTemplate);
      CrunchTime.User.updateCrunchTimeEnableState(false);
    });
  },
  updateCrunchTimeEnableState: function(forceUpdate) {
    CrunchTime.isAvailable(forceUpdate).then(
      function(enable) {
        if (enable.available) {
          $("#orderSubmit").prop("disabled", false);
        }
        else if (!enable.available){
          $("#orderSubmit").prop("disabled", true);
        }
      }
    );
  }
};
