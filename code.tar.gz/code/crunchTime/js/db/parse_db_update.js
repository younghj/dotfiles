addRoles: function(){
    var roleACL = new Parse.ACL();
    roleACL.setPublicReadAccess(true);
    roleACL.setPublicWriteAccess(true);

    var developer = new Parse.Role("Developer", roleACL);
    var admin = new Parse.Role("Admin", roleACL);
    var employee = new Parse.Role("Employee", roleACL);
    var user = new Parse.Role("User", roleACL);

    user.save();
    developer.save();
    employee.save();
    admin.save();

    // Yes this is hacky, but I dont feel like chaining a million callbacks
    setTimeout(function(){
      <!-- Admin -->
      developer.getRoles().add(admin);
      employee.getRoles().add(admin);
      user.getRoles().add(admin);
      admin.getUsers().add(Parse.User.current());

      <!-- Developer -->
      user.getRoles().add(developer);
      employee.getRoles().add(developer);

      user.save();
      developer.save();
      employee.save();
      admin.save();
    }, 10000);
}
