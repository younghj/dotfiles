/**
 * Register object for crunchtime events
 */
document.addEventListener("CrunchTime.User.Startup", function() {
  // console.log("CrunchTime.RunnerRequests.checkUserRunnerStatus");
  CrunchTime.RunnerRequests.checkUserRunnerStatus();
}, false);

document.addEventListener("CrunchTime.Developer.Startup", function() {
  CrunchTime.RunnerRequests.init();
}, false);

document.addEventListener("CrunchTime.ClearCache", function() {
  CrunchTime.RunnerRequests.reset();
}, false);

/**
 * Handles employee requests
 * @type {Object}
 */
window.CrunchTime.RunnerRequests = {

  query: null,
  employeeRole: null,
  requestCache: {},
  requestObj: Parse.Object.extend("RunnerRequests"),

  /**
   * Contains any UI related tasks,
   * You can replace the methods in this with your own ui functions if you so desire.
   ** The function signatures MUST remain the same however.
   * @type {Object}
   */
  ui: {
    REFRESH_BTN_ID: "runner_requests_refresh",
    APPROVE_BTN_ID: "runner_requests_approve",
    DECLINE_BTN_ID: "runner_requests_decline",
    APPLY_BTN_ID: "runner_requests_apply",

    /**
     * add request to user request multiselect
     * @param {Parse.Request} request
     */
    addRequestToList: function(request) {
      var elOption = $('<option></option>');
      elOption.attr("id", "request_" + request.id);
      elOption.attr("value", request.id);
      elOption.html(request.get("username") || request.get("user").id);

      $("#runner_requests_select").append(elOption);
    },

    /**
     * Remove request from list
     * @param {String} requestId ID of request object to remove from multiselect
     */
    removeRequestFromList: function(requestId) {
      $("#request_" + requestId).remove();
    },

    /**
     * Disable button if loading
     * @param {Boolean} isLoading
     * @param {String}  buttonId
     * @param {String}  buttonText
     */
    setBtnLoadingState: function(isLoading, buttonId, buttonText) {
      var elButton = $("#" + buttonId);
      elButton.html(buttonText);

      if (isLoading) {
        elButton.attr("disabled", "disabled");
      } else {
        elButton.removeAttr("disabled");
      }
    },

    getSelectedRequests: function() {
      return $("#runner_requests_select").val();
    },

    clearRequestList: function() {
      $("#runner_requests_select").html('');
    },

    reset: function() {
      this.clearRequestList();
    }
  },

  /**
   * Approve or decline a list of requests
   * @param {String[]} requestIds
   * @param {Boolean} approve    Approve or decline
   */
  processSelectedRequests: function(requestIds, approve) {
    if (!requestIds) {
      return Parse.Promise.as();
    }

    var processedRequests = [];

    requestIds.forEach(function(requestId) {
      var request = this.requestCache[requestId];
      processedRequests.push(request);

      request.set({
        "processedBy": Parse.User.current(),
        "processedDate": new Date(),
        "approved": approve
      });

      if (approve) {
        this.employeeRole.getUsers().add(request.get("user"));
      }
    }, this);

    var _this = this;
    return Parse.Object.saveAll(processedRequests).then(function(saved) {
      if (saved) {
        return _this.employeeRole.save();
      } else {
        return Parse.Promise.error("Request objects could not be updated");
      }

    }).then(function() {
      _this.removeRequests(requestIds);
    });
  },

  processQueriedRequests: function(requestList) {
    this.requestCache = {};

    requestList.forEach(function(request) {
      this.requestCache[request.id] = request;
      this.ui.addRequestToList(request);
    }, this);
  },

  removeRequests: function(requestIds) {
    requestIds.forEach(function(requestId) {
      this.ui.removeRequestFromList(requestId);
      delete this.requestCache[requestId];
    }, this);
  },

  /**
   * OnClick Handlers:
   */

  approveSelectedRequests: function() {
    var _this = CrunchTime.RunnerRequests;
    var requestIds = _this.ui.getSelectedRequests();

    this.ui.setBtnLoadingState(true, "runner_requests_approve", "Approving...");
    this.processSelectedRequests(requestIds, true).fail(function(error) {
      alert("Could not approve users! " + error);
      //console.error(error);

    }).always(function() {
      _this.ui.setBtnLoadingState(false, "runner_requests_approve", "Approve");
    });
  },

  declineSelectedRequests: function() {
    var _this = CrunchTime.RunnerRequests;
    var requestIds = _this.ui.getSelectedRequests();

    this.ui.setBtnLoadingState(true, "runner_requests_decline", "Declining...");
    this.processSelectedRequests(requestIds, false).fail(function(error) {
      alert("Could not decline users! " + error);
      // console.error(error);

    }).always(function() {
      _this.ui.setBtnLoadingState(false, "runner_requests_decline", "Decline");
    });
  },

  /**
   * refresh for request requests
   * @return {Parse.Promise}
   */
  refreshRequests: function() {
    var _this = CrunchTime.RunnerRequests;

    _this.ui.setBtnLoadingState(true, "runner_requests_refresh", "Refreshing...");
    _this.ui.clearRequestList();

    return _this.query.find().then(function(requests) {
      _this.processQueriedRequests(requests);

    }).always(function() {
      _this.ui.setBtnLoadingState(false, "runner_requests_refresh", "Refresh");
    });
  },

  /**
   * Create new runner request
   * @param  {Element} el Apply button element
   * @return {Parse.Promise}
   */
  apply: function(el) {
    var _this = CrunchTime.RunnerRequests;

    _this.ui.setBtnLoadingState(true, "runner_requests_apply", "Applying...");

    new _this.requestObj().save({
      "user": Parse.User.current(),
      "username": Parse.User.current().get("username")

    }).then(function() {
      $("#runner_ad").html("Your runner request has been sent!");

    }, function(error) {
      if (error !== "USER_EMPLOYEE") {
        alert("We could not send your request right now. Please try again later");
        // console.error("Could not apply user as runner", error);
      }

      _this.ui.setBtnLoadingState(false, "runner_requests_apply", "Apply");

    });
  },

  /**
   * Call to clear runner requests
   */
  reset: function() {
    for (var id in this.requestCache) {
      delete this.requestCache[id];
    }
    this.ui.reset();
  },

  checkUserRunnerStatus: function() {
    var _this = this;

    //remove add if user is already an employee
    CrunchTime.query.checkCurrentUserRole("Employee").then(function(isEmployee) {
      if (!isEmployee) {
        var userRequestQuery = new Parse.Query(_this.requestObj);
        userRequestQuery.equalTo("user", Parse.User.current());
        return userRequestQuery.first();
      }

      return Parse.Promise.error("USER_EMPLOYEE");

    }).then(function(request) {
      if (request) {
        //runner request has been declined
        if (request.get("processedBy") && !request.get("approved")) {
          $("#runner_ad span").html("Your runner request has been declined. " +
            "Please contact support for more information.");
          $("#runner_ad").show();

        } else {
          $("#runner-ad").hide();
        }
      } else {
        $("#runner_ad").show();
      }

    });
  },

  /**
   * Init function
   */
  init: function() {
    //set query criteria
    this.query = new Parse.Query(this.requestObj);
    this.query.doesNotExist("processedBy");
    var _this = this;

    CrunchTime.query.role("Employee").then(function(employeeRole) {
      _this.employeeRole = employeeRole;
      _this.refreshRequests();

    }, function(error) {
      if (error !== "NOT_DEVELOPER") {
        // console.error("Cannot check for developer role.", error);
      }
    });
  }
};
