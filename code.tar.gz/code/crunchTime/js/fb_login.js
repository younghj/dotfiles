// PROD
// Parse.initialize("qYqLDK5bBQyN0DIlG6K68KmSWdVFaXroFy1nQ4JP", "LpAFz24SWNZmmhARBDcHEzzj0QzRYhAZoLnRlihU");
// STAGE
// Parse.initialize("j5nOBzdbGbV7V8moN5sSqRDSAC4ptYboTFeftxXc", "RNorSRCumkPkur7dN9AY0Gfs8En1tgyM8JAApZ6K");
// DEV
Parse.initialize("CksJtx8kei4wr5xg3OjyazeJydWWtPXVaGP7Fu34", "wXghTNjBlEe8w7PYUoFVY6N7GWi3cqO4GKNymE9q");

window.fbAsyncInit = function() {
   Parse.FacebookUtils.init({
    // PROD
    // appId      : '332319790286262',
    // STAGE
    // appId      : '344055269112714',
    // DEV
    appId      : '332327206952187',
    cookie     : true,  // enable cookies to allow the server to access
                        // the session
    xfbml      : true,  // parse social plugins on this page
    version    : 'v2.1' // use version 2.1
  });
};

// Load the SDK asynchronously
(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
