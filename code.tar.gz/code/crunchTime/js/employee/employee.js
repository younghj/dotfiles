/**
 * Register object for crunchtime events
 */
document.addEventListener("CrunchTime.Employee.Startup", function() {
  CrunchTime.Employee.init();
}, false);

CrunchTime.Employee = {
  init: function() {
    $(document).ready(function(){
      var orderTemplate = CrunchTime.orderTemplate.cloneNode(true);
      orderTemplate.id = CrunchTime.orderTemplate.id.replace("TYPE", CrunchTime.AssignedOrders.DASHBOARD_EMPL);
      $("#task-dashboard").append(orderTemplate);
      CrunchTime.AssignedOrders.updateTasks();
      CrunchTime.Employee.changeOverrideButtons();
    });
  },
  overrideAvailability: function() {
    CrunchTime.isAvailable().then(
      function(enable) {
        Parse.Cloud.run("overrideAvailability", {"available": !enable.available},
          function(success){
            CrunchTime.Employee.changeOverrideButtons(true);
          },
          function(error){}
        );
      }
    );
  },
  changeOverrideButtons: function(forceUpdate) {
    CrunchTime.isAvailable(forceUpdate).then(
      function(enable) {
        if (!enable.available) {
          $("#enabledCrunchTimeBtn").text("Enable Crunch Time Service");
          $("#enabledCrunchTimeBtn").show();
        }
        else if (enable.available && enable.override) {
          $("#enabledCrunchTimeBtn").text("Disable Crunch Time Service Override");
          $("#enabledCrunchTimeBtn").show();
        }
        else if (enable.available && !enable.override){
          $("#enabledCrunchTimeBtn").hide();
        }
      }
    );
  }
};
