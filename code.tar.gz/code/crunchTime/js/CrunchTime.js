var CrunchTime = {
  available: undefined,
  override: undefined,
  isAvailable: function(forceUpdate) {
    if (CrunchTime.available === undefined || CrunchTime.override === undefined || forceUpdate) {
      // Check if Crunch Time is available
      return Parse.Cloud.run("isCrunchTimeAvailable", {"date": new Date()}).then(
        function(enable) {
          CrunchTime.available = enable.available;
          CrunchTime.override = enable.override;
          return {available: CrunchTime.available, override: CrunchTime.override};
        }
      );
    }
    return Parse.Promise.as({available: CrunchTime.available, override: CrunchTime.override});
  },
  auth: {
    fb: function() {
      Parse.FacebookUtils.logIn(null, {
        success: function(user) {
          if (!user.existed()) {
            FB.api('/me', function(response) {
              if (response.email != null) {
                user.set("firstName", response.first_name);
                user.set("lastName", response.last_name);
                user.set("email", response.email.toLowerCase());
                user.save();
              }
            });
            CrunchTime.addUser(user);
          } else {
            // Login success
            CrunchTime.Home.load();
          }
        },
        error: function(user, error) {}
      });
    },

    signUp: function(email, pass ,passConfirm) {
      var newUser = new Parse.User();
      newUser.set("username", email.toLowerCase());
      newUser.set("email", email.toLowerCase());
      newUser.set("password", pass);
      newUser.signUp(null, {
        success: function(newUser) {
          alert("Sign up successful! You can now place orders using your account.")
          CrunchTime.addUser(newUser);
          CrunchTime.Home.load();
        },
        error: function(newUser, error) {
          // Signup failed
          alert(error.message);
          console.log("does")
        }
      });      
    },

    login: function(email, pass) {
      Parse.User.logIn(email, pass, {
        success: function(user) {
          CrunchTime.Home.load();
        },
        error: function(user, error) {
          // Login failed
          alert(error.message);
        }
      });
    }
  },

  query: {
    /**
     * Cache of current users roles
     * @type {Parse.Role[]}
     */
    currentUserRoles: [],

    /**
     * Check to see if the current user is under a role.
     * This method caches the current user's roles after retrieving them,
     * so that we don't request Parse every time
     * @param {String} roleName
     *
     * @return {Parse.Promise<Boolean>}
     */
    checkCurrentUserRole: function(roleName) {
      return this.getCurrentUserRoles().then(function(currentUserRoles) {
        for (var i = 0; i < currentUserRoles.length; ++i) {
          if (currentUserRoles[i].get("name") === roleName) {
            return true;
          }
        }

        return false;
      });
    },

    /**
     * Gets a list of the roles the current user is under
     * @return {Parse.Promise<Parse.Role[]>}
     */
    getCurrentUserRoles: function() {
      if (Parse.User.current() === null) {
        return Parse.Promise.error("Current user does not exist.");
      }

      if (this.currentUserRoles.length > 0) {
        return Parse.Promise.as(this.currentUserRoles);

      } else {
        var _this = this;
        var rolesQuery = new Parse.Query(Parse.Role).equalTo("users", Parse.User.current());

        return rolesQuery.find().then(function(currentUserRoles) {
          _this.currentUserRoles = currentUserRoles;
          return currentUserRoles;
        });
      }
    },

    /**
     * @return {Parse.Promise<Boolean>}
     */
    isRole: function(roleName, userId) {
      if (userId === Parse.User.current().id) {
        return this.checkCurrentUserRole(roleName);
      }

      var role = CrunchTime.query.role(roleName);
      return role.then(function(roleObj) {
        if (roleObj == null) {
          return false;
        }
        var relation = new Parse.Relation(roleObj, 'users');
        var queryUser = relation.query();
        queryUser.equalTo('objectId', userId);
        return queryUser.first().then(function(val) {
          return (val !== null);
        });
      });
    },
    // Returns Promise<Parse.Role>
    role: function(roleName) {
      var queryRole = new Parse.Query(Parse.Role);
      queryRole.equalTo('name', roleName);
      return queryRole.first({
        success: function(result) { // Role
          return result;
        },
        error: function(error) {
          // console.error(error);
          return null;
        }
      });
    },
    // Returns Promise<className[]>
    all: function(className) {
      var query = new Parse.Query(className);
      return query.find({
        success: function(results) {
          return results;
        },
        error: function(error) {
          // console.error(error);
          return error;
        }
      });
    }

  },

  /**
   * Object for handling repetitive polling tasks
   * @type {Object}
   */
  polling: {
    pollingIds: {},
    isPollingLocked: {},

    /**
     * Stop polling all tasks
     */
    reset: function() {
      for (var id in this.pollingIds) {
        clearInterval(id);
        delete this.pollingIds[id];
      }
    },

    /**
     * Start polling a task
     * @param  {String}  id A unique id for the polling task
     * @param  {Number}  time Time (in Milliseconds) to repeat the task
     * @param  {Function}  pollingFunction A method to call each interval. Method MUST return a Parse.Promise
     * @param  {Object} [thisContext=null] thisContext Context to pass to the polling method
     */
    start: function(id, time, pollingFunction, thisContext) {
      if (this.pollingIds[id] == null) {
        // console.info("Starting polling task: " + id);

        this.pollTask(id, pollingFunction, thisContext);

        this.pollingIds[id] = setInterval(function() {
          CrunchTime.polling.pollTask(id, pollingFunction, thisContext);
        }, time);
      }
    },

    /**
     * Stop a polling task
     * @param  {String} id Id of the task
     */
    stop: function(id) {
      // console.info("Stopping polling task: " + id);
      clearInterval(this.pollingIds[id]);
      this.pollingIds[id] = null;
    },

    pollTask: function(id, pollingFunction, thisContext) {
      if (!this.isPollingLocked[id]) {
        // console.info("polling task: " + id);

        this.isPollingLocked[id] = true;

        pollingFunction.call(thisContext).always(function() {
          CrunchTime.polling.isPollingLocked[id] = false;
        });
      }
    },

    /**
     * Check if a task is running
     * @param {String} id
     * @return {Boolean}
     */
    isRunning: function(id) {
      return (this.pollingIds[id] != null);
    }
  },

  // Add the "User" role to the new user
  addUser: function(user) {
    CrunchTime.query.role("User").then(
      function(userRole) {
        userRole.getUsers().add(user);
        userRole.save();
      }
    );
  },

  clearCache: function() {
    while (CrunchTime.query.currentUserRoles.length) {
      CrunchTime.query.currentUserRoles.pop();
    }
    CrunchTime.polling.reset();
    document.dispatchEvent(new Event("CrunchTime.ClearCache"));
  }
};
/*
// KEEP THIS HERE
// Init Functions
var roleRelationInit = function() {
    var roleACL = new Parse.ACL();
    roleACL.setPublicReadAccess(true);
    roleACL.setPublicWriteAccess(true);

    var developer = new Parse.Role("Developer", roleACL);
    var admin = new Parse.Role("Admin", roleACL);
    var employee = new Parse.Role("Employee", roleACL);
    var user = new Parse.Role("User", roleACL);

    user.save();
    developer.save();
    employee.save();
    admin.save();

    // Yes this is hacky, but I dont feel like chaining a million callbacks
    setTimeout(function(){
      <!-- Admin -->
      developer.getRoles().add(admin);
      employee.getRoles().add(admin);
      user.getRoles().add(admin);
      admin.getUsers().add(Parse.User.current());

      <!-- Developer -->
      user.getRoles().add(developer);
      employee.getRoles().add(developer);

      user.save();
      developer.save();
      employee.save();
      admin.save();
    }, 10000);
  };
  var selfAdmin = function(){
    var userId = Parse.User.current().id;
    var roleName = "Admin";
    var queryUser = new Parse.Query(Parse.User);
    queryUser.equalTo('objectId', userId);
    return queryUser.first({
      success: function(user) {
        if (user == null) {
          console.log("User does not exist");
          return false;
        }
        return CrunchTime.query.role(roleName).then(
          function(role) {
            if (role == null) {
              console.log("Role does not exist");
              return false;
            }
            role.getUsers().add(user);
            return role.save(null, {
              success: function() {
                return true;
              },
              error: function() {
                return false;
              }
            });
          }
        );
      },
      error: function(error) {
        console.log(error);
        return false;
      }
    });
  }
  */
