 // Everything that has to do with the landing page
signupConf = false;
CrunchTime.landing = {
  // Initialize everything on the landing page
  init: function() {
    if (Parse.User.current() == null) {
	  // Initialize login page
	  $("body").load("landing/landing.html", function() {
	    // Initialize the button click handlers

	    document.getElementById("signUpButton").addEventListener("click",
		  function(e) {
		    // Disabled the login button and change this button to become the form submit
			e.preventDefault();
			// this.removeEventListener();
			// $(this).attr("type", "submit")
			var signingUpState = $("#passFieldConfirm").is(":hidden")
			if(!signingUpState){
				CrunchTime.landing.hideSignUpForm();
				$("form[name='loginForm']").attr("action", "javascript:CrunchTime.landing.login();");
			}else{
				CrunchTime.landing.showSignUpForm();
				$("form[name='loginForm']").attr("action", "javascript:CrunchTime.landing.signUp();");
			}
			
			// $("#loginButton").prop("disabled", true);
		  }
	    );

	    // FB button already has built-in flow
	    //
		
		// Input listeners for passcode
		$("#passFieldConfirm,#passField").bind("input", function(){
          var passVal = $("#passField").val();
          var confirmedPassVal = $("#passFieldConfirm").val();
          if(confirmedPassVal!="" && confirmedPassVal!=passVal && passVal!=""){
            $("#passFieldConfirm").css({
              "color" : "#CC0000"
            });
            signupConf = false;
          } else {
            $("#passFieldConfirm").css({
              "color" : "#FFEA3E"
            });
            signupConf = true;
		  }
		});                               
	  });
    } else {
	  CrunchTime.Home.load();
    }
  },
  login: function() {
    var email = document.getElementById("emailField");
	var pass = document.getElementById("passField");
	CrunchTime.auth.login(email.value.toLowerCase(), pass.value);
  },
  signUp: function() {
    var email = document.getElementById("emailField");
	var pass = document.getElementById("passField");
	var passConfirm = document.getElementById("passFieldConfirm");
	if(signupConf){
		CrunchTime.auth.signUp(email.value.toLowerCase(), pass.value, passConfirm.value);
	}
    
  },
  showSignUpForm: function() {
    $("#passFieldConfirm").parent().show();
    $("#signUpButton").html("Cancel")
    $("#loginButton").attr("value","Sign Up")
  },
  hideSignUpForm: function(){
  	$("#passFieldConfirm").parent().hide();
  	$("#signUpButton").html("Sign Up")
  	$("#loginButton").attr("value","Login")
  }
}
