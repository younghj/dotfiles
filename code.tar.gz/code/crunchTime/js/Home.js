/**
 * Anything to do with the home page
 * @type {Object}
 */

CrunchTime.Home = {
  load: function() {
    $("body").load("home.html", this.afterLoad);
    this.spinner(true);

    document.dispatchEvent(new Event("CrunchTime.Startup"));
  },

  /**
   * Displays or hides the page spinner
   * this should be implemented when the ui gets built
   * @param  {Boolean} isOn
   */
  spinner: function(isOn) {
    return;
  },

  /**
   * Load/Remove tabs as necessary
   */
  loadTabs: function() {
    var promise = CrunchTime.query.checkCurrentUserRole("Admin").then(function(isRole) {
      if (isRole) {
        $("#admin-content").load("admin/admin_home.html", function() {
          document.dispatchEvent(new Event("CrunchTime.Admin.Startup"));
        }).show();
        $("#admin-tab-bc").show();

      } else $("#admin-tab, #admin-tab-bc").remove();
    });

    promise = promise.then(function() {
      return CrunchTime.query.checkCurrentUserRole("Developer").then(function(isRole) {
        if (isRole) {
          $("#developer-content").load("developer/developer_home.html", function() {
            document.dispatchEvent(new Event("CrunchTime.Developer.Startup"));
          }).show();
          $("#developer-tab-bc").show();
        } else $("#developer-tab, #developer-tab-bc").remove();
      });
    });

    promise = promise.then(function() {
      return CrunchTime.query.checkCurrentUserRole("Employee").then(function(isRole) {
        if (isRole) {
          $("#employee-content").load("employee/employee_home.html", function() {
            document.dispatchEvent(new Event("CrunchTime.Employee.Startup"));
          });
          $("#employee-tab-bc").show();

        } else $("#employee-tab, #employee-tab-bc").remove();
      });
    });

    promise = promise.then(function() {
      return CrunchTime.query.checkCurrentUserRole("User").then(function(isRole) {
        if (isRole) {
          $("#user-content").load("user/user_home.html", function() {
            document.dispatchEvent(new Event("CrunchTime.User.Startup"));
          });
          $("#user-tab-bc").show();

        } else $("#user-tab, #user-tab-bc").remove();
      });
    });

    return promise;
  },

  afterLoad: function(responseText, textStatus, jqXHR) {
    if (textStatus === "error") {
      alert("Sorry, but an error occured during login. " +
        "Please contact support. Error:" + jqXHR.status + " " + jqXHR.statusText);
      // console.error("Could not load home", responseText, textStatus, jqXHR);
      return;
    }

    //load tabs
    CrunchTime.Home.loadTabs().then(function() {
      //set event listeners
      $('.tabs .tab-links a').on('click', CrunchTime.Home.tabOnClick);

      // Show the first tab
      $('.tab-links li a').first().click();
      $("#logoutButton").on("click", CrunchTime.Home.logoutOnClick);

      // Hide tab links if only one tab is present
      var numTabs = $('.tab-link').length;
      if (numTabs <= 1) {
        $('.tab-links').remove();
      }

      CrunchTime.isAvailable().then(
        function(enable) {
          if (enable.available) {
            $(".unavailable-msg").hide();
          } else {
            $(".unavailable-msg").show();
          }
        }
      );
    });
  },


  toggleCollapse: function(el) {
    $(el).find('.collapse').collapse('toggle');
    $(el).find('.arrow .glyphicon').toggleClass('glyphicon-chevron-right glyphicon-chevron-down');
  },

  /**
   * Click Handlers
   */

  /**
   * @param {MouseEvent} e
   */
  tabOnClick: function(e) {
    var currentAttrValue = $(this).attr('href');

    // Show/Hide Tabs
    $('.tabs ' + currentAttrValue).show().siblings().hide();

    // Change/remove current tab to active
    $(this).parent('li').addClass('active').siblings().removeClass('active');

    e.preventDefault();

    CrunchTime.Home.pollingUtils.activeTab = this.parentElement.id.replace("-tab-bc", "");
    CrunchTime.Home.pollingUtils.switchTab();
  },

  /**
   * @param {MouseEvent} e
   */
  logoutOnClick: function(e) {
    Parse.User.logOut();
    FB.logout();
    CrunchTime.Home.reset();
    CrunchTime.clearCache();
    // CrunchTime.landing.init();
    history.go(0)
  },

  /**
   * Handle the starting and stopping of different polling tasks
   * depending on the selected tab
   * @type {Object}
   */
  pollingUtils: {
    /**
     * Caches for tasks. DO NOT MODIFY
     * Call either 'register' or 'unregister' add/remove polling tasks
     * @type {Object}
     */
    activeTasks: {},

    adminTasks: {},
    developerTasks: {},
    employeeTasks: {},
    userTasks: {},

    /**
     * Register a polling tasks to start once the user switches to a tab
     * @param  {String}  tabName
     * @param  {String}  id      Task Id
     * @param  {Number}  time    Polling interval (in milliseconds)
     * @param  {Function}  method  Polling function
     * @param  {Object} thisContext 'this' context to set when calling polling method
     */
    register: function(tabName, id, time, method, thisContext) {
      this[tabName.toLowerCase() + "Tasks"][id] = {
        "time": time,
        "method": method,
        "thisContext": thisContext
      };

      //if we're registering a task for the active tab
      if (tabName.toLowerCase() === this.activeTab) {
        CrunchTime.polling.start(id, time, method, thisContext);
      }
    },

    unregister: function(tabName, id) {
      delete this[tabName.toLowerCase() + "Tasks"][id];
    },

    startTasks: function(newTasks) {
      this.activeTasks = newTasks;

      for (var taskId in this.activeTasks) {
        try {
          var task = this.activeTasks[taskId];
          CrunchTime.polling.start(taskId, task.time, task.method, task.thisContext);
        } catch (e) {
          // console.error("Could not start polling task: " + this.activeTasks[taskId], e);
        }
      }
    },

    /**
     * Stop currently running tasks
     */
    stopActiveTasks: function() {
      for (var taskId in this.activeTasks) {
        CrunchTime.polling.stop(taskId);
      }
    },

    switchTab: function() {
      var newTasks = ((this[this.activeTab]) || this.activeTasks);

      if (newTasks !== this.activeTasks) {
        this.stopActiveTasks();
        this.startTasks(newTasks);
      }
    },

    /**
     * Stop all tasks and empty task caches
     */
    reset: function() {
      this.stopActiveTasks();

      //remove any cache of polling tasks
      for (var id in this.adminTasks) {
        delete this.adminTasks[id];
      }

      for (var id in this.developerTasks) {
        delete this.developerTasks[id];
      }

      for (var id in this.employeeTasks) {
        delete this.employeeTasks[id];
      }

      for (var id in this.userTasks) {
        delete this.userTasks[id];
      }
    }
  },

  reset: function() {
    this.pollingUtils.reset();
  }
};
