$(function() {
    $('.spaceball').remove();
})
