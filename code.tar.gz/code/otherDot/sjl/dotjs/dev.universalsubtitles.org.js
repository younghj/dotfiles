$('#menu_name > a').attr('href', '#');
$('div#menu_name > a').click(function() {
    $('div#menu').toggle();
});
