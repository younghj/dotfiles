//$('#comments-view').remove();
$('#ticker').remove();
