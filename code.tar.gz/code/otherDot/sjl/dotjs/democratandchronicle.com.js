$('.fb_recommend, .aside center, .aside table, #taboola-leftcolumn-div').remove();
$('#dir_widget_wrapper, #conveyorbottom, .ody-ob-taboola-wrapper').remove();
$('.footer-partners, .footer-gannett, .footer-bottom').remove();

