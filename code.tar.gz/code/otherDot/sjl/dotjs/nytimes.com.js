$('.socialMediaModule').remove();

$('#wsodMarkets').remove();
$('#classifiedsWidget').remove();
$('.cColumn #cColumnTopSpanRegion').remove();
$('#recommendedFooter').remove();
$('#mostPopWidget').remove();
