$('#url-field div button').remove();
